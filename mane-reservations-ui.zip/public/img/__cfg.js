window.__CFG = Object.assign({}, window.__CFG, {
  API_BASE_URL: "https://api.mane.com.vc"
});