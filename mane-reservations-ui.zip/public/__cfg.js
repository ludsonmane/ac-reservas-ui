// public/__cfg.js
// Runtime config (carrega antes do bundle). Ajuste aqui para apontar o painel local
// para a API ONLINE, sem precisar subir nada.

// Exemplo:
// window.__CFG = { API_BASE_URL: 'https://api.mane.com.vc' };

window.__CFG = window.__CFG || {};
window.__CFG.API_BASE_URL = window.__CFG.API_BASE_URL || 'https://api.mane.com.vc';
