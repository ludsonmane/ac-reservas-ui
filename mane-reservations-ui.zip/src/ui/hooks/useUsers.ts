import { useEffect, useState } from 'react';
import { api } from '../../lib/api';

export type UserRow = {
  id: string;
  name: string;
  email: string;
  role: 'ADMIN' | 'CONCIERGE';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

export function useUsers(filters: any) {
  const [data, setData] = useState<{items: UserRow[]; total: number; page: number; totalPages: number}>({
    items: [], total: 0, page: 1, totalPages: 1
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancel = false;
    (async () => {
      setLoading(true);
      try {
        const qs = new URLSearchParams({
          page: String(filters.page || 1),
          pageSize: String(filters.pageSize || 20),
          search: filters.search || '',
          active: filters.active ?? 'all',
        });
        const res = await api(`/v1/users?${qs.toString()}`, { auth: true });
        if (!cancel) setData(res);
      } catch {
        if (!cancel) setData({ items: [], total: 0, page: 1, totalPages: 1 });
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    return () => { cancel = true; };
  }, [filters.page, filters.pageSize, filters.search, filters.active]);

  return { data, loading };
}
