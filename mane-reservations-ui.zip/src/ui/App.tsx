// src/ui/App.tsx
import React, { useEffect, useState } from 'react';
import { api, getBaseUrl } from '../lib/api';
import { invalidate } from '../lib/query';
import { useStore, setToken, clearAuth, setUser } from '../store';
import type { Reservation, User } from '../types';
import Skeleton from './Skeleton';
import Toaster from './Toaster';
import { toast } from './toast';
import { useUnits } from './hooks/useUnits';
import { useReservations } from './hooks/useReservations';
import UnitsPage from './UnitsPage';
import { useAreasByUnit } from './hooks/useAreasByUnit';
import AreasPage from './AreasPage';

/* ---------- Loading Modal (inline) ---------- */
function LoadingDialog({
  open = false,
  title = 'Entrando...',
  message = 'Validando suas credenciais. Aguarde um instante.',
}: { open?: boolean; title?: string; message?: string }) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div className="card w-full max-w-sm text-center">
        <div className="mx-auto mb-3 h-10 w-10 rounded-full border-2 border-border border-t-primary animate-spin" />
        <h3 className="title text-lg mb-1">{title}</h3>
        <p className="text-sm text-muted">{message}</p>
      </div>
    </div>
  );
}

/* ---------- Topbar ---------- */
function Topbar() {
  const { user } = useStore();
  return (
    <header className="sticky top-0 z-10 bg-gradient-to-b from-[#e8f5ea] to-panel backdrop-blur border-b border-border">
      <div className="container flex items-center gap-3 py-3">
        <h1 className="title text-lg opacity-90">Mané • Admin Reservas</h1>
        <div className="flex-1" />
        <div className="text-sm text-muted">API: {getBaseUrl()}</div>
        {user && (
          <>
            <div className="text-sm text-muted">
              {user.name} ({user.role})
            </div>
            <button
              className="btn btn-ghost btn-sm"
              onClick={async () => {
                try { await api('/auth/logout', { method: 'POST', auth: true }); } catch { }
                clearAuth();
                invalidate('*');
                toast.success('Você saiu da aplicação.');
                window.location.replace(window.location.origin + window.location.pathname);
              }}
              title="Sair"
            >
              Sair
            </button>
          </>
        )}
      </div>
    </header>
  );
}

/* ---------- Login ---------- */
function LoginCard() {
  const [email, setEmail] = useState('admin@mane.com.vc');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function doLogin() {
    if (loading) return;
    setLoading(true);
    try {
      const data = await api('/auth/login', { method: 'POST', body: { email, password } });
      const token = data.accessToken || data.token;
      if (!token) throw new Error('Token ausente');
      setToken(token);
      setUser(data.user as User);
      invalidate('*');
      toast.success('Login realizado com sucesso!');
    } catch (e: any) {
      console.error(e);
      const msg =
        e?.error?.error ||
        e?.error?.message ||
        e?.message ||
        'Falha no login. Verifique email e senha.';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="container mt-6">
      <LoadingDialog open={loading} title="Entrando..." message="Validando suas credenciais. Aguarde um instante." />
      <div className="card max-w-lg mx-auto">
        <h2 className="title text-2xl mb-3">Login</h2>
        <div className="grid grid-cols-2 gap-3">
          <label className="col-span-2">
            <span>E-mail</span>
            <input
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              required
              disabled={loading}
              aria-disabled={loading}
              aria-busy={loading}
              autoFocus
            />
          </label>
          <label className="col-span-2">
            <span>Senha</span>
            <input
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              required
              disabled={loading}
              aria-disabled={loading}
              aria-busy={loading}
              onKeyDown={(e) => {
                if (e.key === 'Enter') doLogin();
              }}
            />
          </label>
          <div className="col-span-2 flex justify-end gap-2">
            <button
              className="btn btn-primary"
              disabled={loading}
              onClick={doLogin}
            >
              {loading ? 'Entrando…' : 'Entrar'}
            </button>
          </div>
          <p className="text-muted text-sm col-span-2">Use as credenciais do /auth/login.</p>
        </div>
      </div>
    </section>
  );
}

/* ---------- helpers ---------- */
function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, '0');
  const y = d.getFullYear();
  const m = pad(d.getMonth() + 1);
  const da = pad(d.getDate());
  const h = pad(d.getHours());
  const mi = pad(d.getMinutes());
  return `${y}-${m}-${da}T${h}:${mi}`;
}

/* ---------- Botão de ícone (menor + tooltip) ---------- */
function IconBtn({
  title,
  onClick,
  variant = '',
  danger = false,
  disabled,
  children,
}: {
  title: string;
  onClick?: () => void;
  variant?: string;
  danger?: boolean;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center btn btn-sm ${danger ? 'btn-danger' : variant
        } h-9 w-9 p-0 rounded-full`}
      onClick={onClick}
      title={title}
      aria-label={title}
      disabled={disabled}
    >
      <span className="text-[20px] leading-none pointer-events-none">
        {children}
      </span>
      <span className="sr-only">{title}</span>
    </button>
  );
}

/* ---------- Ícones (SVG 20px, herdando cor) ---------- */
const PencilIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="20"
    height="20"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    role="img"
    aria-hidden="true"
    className="block"
  >
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4 11.5-11.5z" />
  </svg>
);

const RefreshIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="20"
    height="20"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    role="img"
    aria-hidden="true"
    className="block"
  >
    <path d="M3 12a9 9 0 0 1 15-6l2 2" />
    <path d="M21 12a9 9 0 0 1-15 6l-2-2" />
    <path d="M20 8V4h-4" />
    <path d="M4 16v4h4" />
  </svg>
);

const TrashIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="20"
    height="20"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    role="img"
    aria-hidden="true"
    className="block"
  >
    <path d="M3 6h18" />
    <path d="M8 6V4h8v2" />
    <path d="M19 6l-1 14H6L5 6" />
    <path d="M10 11v6M14 11v6" />
  </svg>
);

/* ---------- Tabela de Reservas ---------- */
function ReservationsTable({ filters, setFilters }: { filters: any; setFilters: (v: any) => void }) {
  const { data, loading } = useReservations(filters);

  // mapa id -> nome da unidade
  const { units } = useUnits(true);
  const unitsById = React.useMemo<Record<string, string>>(
    () => Object.fromEntries(units.map(u => [u.id, u.name])),
    [units]
  );

  return (
    <>
      <div className="overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Cliente</th>
              <th>Reserva</th>
              <th>Pessoas</th>
              <th>Unidade</th>
              <th>Área</th>
              <th>Origem</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>

          {loading && (
            <tbody>
              {Array.from({ length: 6 }).map((_, i) => (
                <tr key={`sk-${i}`}>
                  <td><Skeleton className="h-5 w-16" /></td>
                  <td>
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-11 w-11" />
                      <div className="flex flex-col gap-2">
                        <Skeleton className="h-4 w-40" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                    </div>
                  </td>
                  <td><Skeleton className="h-4 w-28" /></td>
                  <td><Skeleton className="h-4 w-10" /></td>
                  <td><Skeleton className="h-4 w-20" /></td>
                  <td><Skeleton className="h-4 w-24" /></td>
                  <td><Skeleton className="h-4 w-24" /></td>
                  <td><Skeleton className="h-5 w-20" /></td>
                  <td className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          )}

          {!loading && (
            <tbody>
              {data.items.map((r: Reservation) => {
                const statusClass = r.status === 'CHECKED_IN' ? 'badge-ok' : 'badge-wait';
                const when = new Date(r.reservationDate).toLocaleString();

                const unitLabel =
                  (r as any).unitId ? (unitsById[(r as any).unitId] ?? undefined) :
                    (r as any).unitName ?? (r as any).unit ?? '-';

                const origem = (r as any).utm_source || (r as any).source || '-';

                const base = localStorage.getItem('BASE_URL') || 'http://localhost:4000';
                const qrUrl = `${base}/v1/reservations/${r.id}/qrcode`;

                return (
                  <tr key={r.id}>
                    <td style={{ fontWeight: 900 }}>{r.reservationCode || '-'}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <img src={qrUrl} className="h-11 w-11 rounded border border-border" crossOrigin="anonymous" />
                        <div>
                          <div className="font-medium">{r.fullName}</div>
                          <div className="text-muted text-xs">
                            {r.email || ''}{r.phone ? ' • ' + r.phone : ''}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>{when}</td>
                    <td>{r.people}{r.kids ? ` (+${r.kids})` : ''}</td>
                    <td>{unitLabel || '-'}</td>
                    <td>{(r as any).areaName || (r as any).area || '-'}</td>
                    <td>{origem}</td>
                    <td><span className={`badge ${statusClass}`}>{r.status}</span></td>
                    <td className="text-right">
                      <div className="flex gap-2 justify-end">
                        <IconBtn
                          title="Editar"
                          onClick={() => setFilters({ ...filters, showModal: true, editing: r })}
                        >
                          <PencilIcon />
                        </IconBtn>
                        <IconBtn
                          title="Renovar QR"
                          onClick={async () => {
                            if (!confirm('Gerar novo QR e voltar para AWAITING_CHECKIN?')) return;
                            try {
                              await api(`/v1/reservations/${r.id}/qr/renew`, { method: 'POST', auth: true });
                              setFilters({ ...filters });
                              toast.success('QR renovado e status atualizado.');
                            } catch (e) {
                              toast.error('Erro ao renovar QR.');
                            }
                          }}
                        >
                          <RefreshIcon />
                        </IconBtn>
                        <IconBtn
                          title="Excluir"
                          danger
                          onClick={async () => {
                            if (!confirm('Tem certeza que deseja excluir?')) return;
                            try {
                              await api(`/v1/reservations/${r.id}`, { method: 'DELETE', auth: true });
                              setFilters({ ...filters });
                              toast.success('Reserva excluída.');
                            } catch (e) {
                              toast.error('Erro ao excluir a reserva.');
                            }
                          }}
                        >
                          <TrashIcon />
                        </IconBtn>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {data.items.length === 0 && <tr><td colSpan={9}>Sem resultados</td></tr>}
            </tbody>
          )}
        </table>
      </div>

      <div className="flex items-center justify-center gap-3 text-muted mt-3">
        <button className="btn btn-sm" onClick={() => setFilters({ ...filters, page: Math.max(1, (filters.page || 1) - 1) })}>◀</button>
        <span>Página {data.page} de {data.totalPages} — {data.total} itens</span>
        <button className="btn btn-sm" onClick={() => setFilters({ ...filters, page: (filters.page || 1) + 1 })}>▶</button>
      </div>
    </>
  );
}

/* ---------- Filtros ---------- */
function FiltersBar({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const { units, loading: loadingUnits } = useUnits(true);
  const areasByUnit = useAreasByUnit(value.unitId || undefined, !!value.unitId);

  const unitIdOf = (u: any) => (u && typeof u === 'object' ? u.id : '');
  const unitNameOf = (u: any) => (u && typeof u === 'object' ? u.name : String(u ?? ''));

  return (
    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-2">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 flex-1">
        <label>
          <span>Buscar</span>
          <input
            className="input"
            value={value.search || ''}
            onChange={(e) => onChange({ ...value, search: e.target.value, page: 1 })}
            placeholder="nome, email..."
          />
        </label>

        <label>
          <span>Unidade</span>
          <select
            className="input"
            value={value.unitId || ''}
            onChange={(e) => {
              const newUnitId = e.target.value || '';
              const selected = (units as any[]).find(u => unitIdOf(u) === newUnitId);
              const legacyUnitName = selected ? unitNameOf(selected) : '';
              onChange({ ...value, unitId: newUnitId, unit: legacyUnitName, areaId: '', page: 1 });
            }}
            disabled={loadingUnits}
          >
            <option value="">{loadingUnits ? 'Carregando…' : 'Todas'}</option>
            {(units as any[]).map((u) => (
              <option key={unitIdOf(u)} value={unitIdOf(u)}>{unitNameOf(u)}</option>
            ))}
          </select>
        </label>

        <label>
          <span>Área</span>
          <select
            className="input"
            value={value.areaId || ''}
            onChange={(e) => onChange({ ...value, areaId: e.target.value || '', page: 1 })}
            disabled={!value.unitId || areasByUnit.loading}
          >
            <option value="">
              {!value.unitId ? 'Selecione uma unidade' : (areasByUnit.loading ? 'Carregando…' : 'Todas')}
            </option>
            {areasByUnit.data?.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <span>De</span>
          <input
            className="input"
            type="datetime-local"
            value={value.from || ''}
            onChange={(e) => onChange({ ...value, from: e.target.value, page: 1 })}
          />
        </label>

        <label>
          <span>Até</span>
          <input
            className="input"
            type="datetime-local"
            value={value.to || ''}
            onChange={(e) => onChange({ ...value, to: e.target.value, page: 1 })}
          />
        </label>
      </div>

      <div className="flex gap-2">
        <button className="btn" onClick={() => onChange({ ...value })}>Atualizar</button>
        <button className="btn btn-primary" onClick={() => onChange({ ...value, showModal: true, editing: null })}>
          Nova Reserva
        </button>
      </div>
    </div>
  );
}

/* ---------- Modal (unitId + areaId, puxa áreas da unidade selecionada) ---------- */
function ReservationModal({
  open, onClose, editing, onSaved, defaultUnitId,
}: {
  open: boolean;
  onClose: () => void;
  editing: Reservation | null;
  onSaved: () => void;
  defaultUnitId?: string;
}) {
  const { user } = useStore();
  const isAdmin = user?.role === 'ADMIN';
  const lockMarketing = !!editing && !isAdmin; // concierge só bloqueia em EDIÇÃO

  const [form, setForm] = React.useState<any>(() => ({
    unitId: defaultUnitId ?? null,
  }));
  const [saving, setSaving] = React.useState(false);

  const { units, loading: loadingUnits } = useUnits(open);
  const areasByUnit = useAreasByUnit(form.unitId || undefined, open && !!form.unitId);

  const unitIdOf = (u: any) => (u && typeof u === 'object' ? u.id : '');
  const unitNameOf = (u: any) => (u && typeof u === 'object' ? u.name : String(u ?? ''));

  React.useEffect(() => {
    const f: any = editing
      ? { ...editing }
      : { people: 1, kids: 0, reservationDate: new Date().toISOString(), unitId: defaultUnitId ?? null, areaId: null };

    if (f.reservationDate) f.reservationDate = toLocalInput(f.reservationDate);
    if (f.birthdayDate) f.birthdayDate = f.birthdayDate.substring(0, 10);

    f.unitId = editing?.unitId ?? (defaultUnitId ?? null);
    f.areaId = editing?.areaId ?? null;

    setForm(f);
  }, [editing, open, defaultUnitId]);

  React.useEffect(() => {
    if (open && !editing && defaultUnitId) {
      setForm((s: any) => ({ ...s, unitId: defaultUnitId, areaId: null }));
    }
  }, [defaultUnitId, open, editing]);

  if (!open) return null;

  const set = (k: string, v: any) => setForm((s: any) => ({ ...s, [k]: v }));

  async function handleSave() {
    if (saving) return;
    setSaving(true);
    const payload: any = {
      fullName: form.fullName,
      people: Number(form.people || 1),
      kids: Number(form.kids || 0),

      reservationDate: new Date(form.reservationDate).toISOString(),
      birthdayDate: form.birthdayDate ? new Date(form.birthdayDate).toISOString() : null,

      cpf: form.cpf || null,
      phone: form.phone || null,
      email: form.email || null,
      notes: form.notes || null,

      unitId: form.unitId || null,
      areaId: form.areaId || null,

      utm_source: form.utm_source || null,
      utm_campaign: form.utm_campaign || null,
      source: form.source || null,
    };

    // Concierge não pode alterar marketing em EDIÇÃO (no create pode preencher)
    if (editing && !isAdmin) {
      delete payload.utm_source;
      delete payload.utm_campaign;
      delete payload.source;
    }

    try {
      if (editing) {
        await api(`/v1/reservations/${editing.id}`, { method: 'PUT', body: payload, auth: true });
        toast.success('Reserva atualizada.');
      } else {
        await api('/v1/reservations', { method: 'POST', body: payload, auth: true });
        toast.success('Reserva criada.');
      }
      onSaved();
      onClose();
    } catch (e: any) {
      console.error(e);
      const msg = e?.userMessage || e?.message || 'Erro ao salvar a reserva.';
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={editing ? 'Editar reserva' : 'Nova reserva'}
    >
      <div className="card shadow-none w-full max-w-3xl md:max-w-4xl max-h-[90vh] md:max-h-[85vh] p-0 overflow-hidden flex flex-col">
        <div className="px-5 py-3 border-b border-border bg-card flex items-center justify-between flex-none">
          <h3 className="title text-xl m-0">{editing ? 'Editar' : 'Nova'} Reserva</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose} disabled={saving}>Fechar</button>
        </div>

        <div className="px-5 py-4 overflow-y-auto flex-1 pb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">

            <label>
              <span>Unidade</span>
              <select
                className="input py-2"
                value={form.unitId || ''}
                onChange={(e) => { set('unitId', e.target.value || null); set('areaId', null); }}
                disabled={loadingUnits || saving}
              >
                <option value="">{loadingUnits ? 'Carregando unidades...' : 'Selecione a unidade'}</option>
                {(units as any[]).map((u) => (
                  <option key={unitIdOf(u)} value={unitIdOf(u)}>{unitNameOf(u)}</option>
                ))}
              </select>
            </label>

            <label>
              <span>Nome completo*</span>
              <input
                className="input py-2"
                value={form.fullName || ''}
                onChange={(e) => set('fullName', e.target.value)}
                placeholder="Ex.: Maria Silva"
                disabled={saving}
              />
            </label>

            <label>
              <span>Pessoas*</span>
              <input
                className="input py-2"
                type="number"
                min={1}
                value={form.people ?? 1}
                onChange={(e) => set('people', parseInt(e.target.value || '1'))}
                disabled={saving}
              />
            </label>
            <label>
              <span>Crianças</span>
              <input
                className="input py-2"
                type="number"
                min={0}
                value={form.kids ?? 0}
                onChange={(e) => set('kids', parseInt(e.target.value || '0'))}
                disabled={saving}
              />
            </label>

            <label className="md:col-span-2">
              <span>Área</span>
              <select
                className="input py-2"
                value={form.areaId || ''}
                onChange={(e) => set('areaId', e.target.value || null)}
                disabled={!form.unitId || areasByUnit.loading || saving}
              >
                <option value="">
                  {!form.unitId ? 'Selecione uma unidade' : (areasByUnit.loading ? 'Carregando áreas...' : 'Selecione uma área')}
                </option>
                {areasByUnit.data?.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}{a.capacity ? ` (${a.capacity})` : ''}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>Data da reserva*</span>
              <input
                className="input py-2"
                type="datetime-local"
                value={form.reservationDate || ''}
                onChange={(e) => set('reservationDate', e.target.value)}
                disabled={saving}
              />
            </label>
            <label>
              <span>Data de aniversário</span>
              <input
                className="input py-2"
                type="date"
                value={form.birthdayDate || ''}
                onChange={(e) => set('birthdayDate', e.target.value)}
                disabled={saving}
              />
            </label>

            <label>
              <span>CPF</span>
              <input
                className="input py-2"
                value={form.cpf || ''}
                onChange={(e) => set('cpf', e.target.value)}
                placeholder="000.000.000-00"
                disabled={saving}
              />
            </label>
            <label>
              <span>Telefone</span>
              <input
                className="input py-2"
                value={form.phone || ''}
                onChange={(e) => set('phone', e.target.value)}
                placeholder="(00) 00000-0000"
                disabled={saving}
              />
            </label>

            <label className="md:col-span-2">
              <span>Email</span>
              <input
                className="input py-2"
                type="email"
                value={form.email || ''}
                onChange={(e) => set('email', e.target.value)}
                placeholder="cliente@exemplo.com"
                disabled={saving}
              />
            </label>

            <label className="md:col-span-2">
              <span>Notas</span>
              <textarea
                className="input"
                rows={3}
                value={form.notes || ''}
                onChange={(e) => set('notes', e.target.value)}
                placeholder="Observações adicionais (opcional)"
                disabled={saving}
              />
            </label>

            <label>
              <span>UTM Source</span>
              <input
                className={`input py-2 ${lockMarketing ? 'opacity-60 cursor-not-allowed' : ''}`}
                value={form.utm_source || ''}
                onChange={(e) => set('utm_source', e.target.value)}
                disabled={saving || lockMarketing}
              />
            </label>
            <label>
              <span>UTM Campaign</span>
              <input
                className={`input py-2 ${lockMarketing ? 'opacity-60 cursor-not-allowed' : ''}`}
                value={form.utm_campaign || ''}
                onChange={(e) => set('utm_campaign', e.target.value)}
                disabled={saving || lockMarketing}
              />
            </label>
            <label className="md:col-span-2">
              <span>Source</span>
              <input
                className={`input py-2 ${lockMarketing ? 'opacity-60 cursor-not-allowed' : ''}`}
                value={form.source || ''}
                onChange={(e) => set('source', e.target.value)}
                placeholder="Origem (ex.: WhatsApp, Site, Balcão)"
                disabled={saving || lockMarketing}
              />
            </label>
          </div>
        </div>

        <div className="px-5 py-3 border-t border-border bg-card flex justify-end gap-2 flex-none">
          <button className="btn" onClick={onClose} disabled={saving}>Cancelar</button>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? (
              <span className="inline-flex items-center gap-2">
                <span className="h-4 w-4 rounded-full border-2 border-border border-t-white animate-spin" />
                Salvando…
              </span>
            ) : (
              'Salvar'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Página ---------- */
function ReservationsPanel() {
  const [filters, setFilters] = useState<any>({
    page: 1, pageSize: 10, showModal: false, editing: null,
    unit: '',
    unitId: '',
    areaId: ''
  });
  return (
    <section className="container mt-4">
      <div className="card">
        <h2 className="title text-2xl mb-3">Reservas</h2>
        <FiltersBar value={filters} onChange={setFilters} />
        <ReservationsTable filters={filters} setFilters={setFilters} />
      </div>

      <ReservationModal
        open={!!filters.showModal}
        editing={filters.editing}
        onClose={() => setFilters({ ...filters, showModal: false, editing: null })}
        onSaved={() => setFilters({ ...filters })}
        defaultUnitId={filters.unitId || undefined}
      />
    </section>
  );
}

/* ---------- App (com abas Reservas/Unidades/Áreas) ---------- */
export default function App() {
  const { token, user } = useStore();
  const isAdmin = user?.role === 'ADMIN';
  const [tab, setTab] = useState<'reservas' | 'unidades' | 'areas'>('reservas');

  useEffect(() => {
    const onFocus = () => invalidate('*');
    const onOnline = () => invalidate('*');

    const onVisChange = () => {
      if (document.visibilityState === 'visible') onFocus();
    };

    window.addEventListener('visibilitychange', onVisChange);
    window.addEventListener('focus', onFocus);
    window.addEventListener('online', onOnline);

    return () => {
      window.removeEventListener('visibilitychange', onVisChange);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('online', onOnline);
    };
  }, []);

  // 🔔 Escuta expiração de sessão disparada por api.ts
  useEffect(() => {
    function onAuthExpired(e: any) {
      clearAuth();
      invalidate('*');
      const reason =
        e?.detail?.userMessage ||
        e?.detail?.error?.message ||
        e?.detail?.error ||
        'Sua sessão expirou. Faça login novamente.';
      toast.error(reason);
    }
    window.addEventListener('auth:expired', onAuthExpired);
    return () => window.removeEventListener('auth:expired', onAuthExpired);
  }, []);

  useEffect(() => {
    if (token && !user) {
      (async () => {
        try {
          const me = await api('/auth/me', { auth: true });
          setUser(me.user as User);
        } catch {
          clearAuth();
        }
      })();
    }
  }, [token, !!user]);

  return (
    <div>
      <Toaster />
      <Topbar />
      {!token ? (
        <LoginCard />
      ) : (
        <>
          <section className="container mt-4">
            <div className="flex gap-2">
              <button
                className={`btn ${tab === 'reservas' ? 'btn-primary' : ''}`}
                onClick={() => setTab('reservas')}
              >
                Reservas
              </button>

              {/* 👇 Concierge não vê as abas de gestão */}
              {isAdmin && (
                <>
                  <button
                    className={`btn ${tab === 'unidades' ? 'btn-primary' : ''}`}
                    onClick={() => setTab('unidades')}
                  >
                    Unidades
                  </button>
                  <button
                    className={`btn ${tab === 'areas' ? 'btn-primary' : ''}`}
                    onClick={() => setTab('areas')}
                  >
                    Áreas
                  </button>
                </>
              )}
            </div>
          </section>

          {tab === 'reservas' ? (
            <ReservationsPanel />
          ) : tab === 'unidades' ? (
            <UnitsPage />
          ) : (
            <AreasPage />
          )}
        </>
      )}
    </div>
  );
}
