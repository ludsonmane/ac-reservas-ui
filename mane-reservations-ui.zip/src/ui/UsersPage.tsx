import React from 'react';
import { api } from '../lib/api';
import { toast } from './toast';
import Skeleton from './Skeleton';
import { useUsers } from './hooks/useUsers';

function UserModal({ open, onClose, editing, onSaved }: {
  open: boolean;
  onClose: () => void;
  editing: any | null;
  onSaved: () => void;
}) {
  const [saving, setSaving] = React.useState(false);
  const [form, setForm] = React.useState<any>({ role: 'CONCIERGE', isActive: true });

  React.useEffect(() => {
    if (!open) return;
    setForm(editing ? { ...editing, password: '' } : { name: '', email: '', role: 'CONCIERGE', isActive: true, password: '' });
  }, [open, editing]);

  if (!open) return null;
  const set = (k: string, v: any) => setForm((s: any) => ({ ...s, [k]: v }));

  async function handleSave() {
    if (saving) return;
    setSaving(true);
    try {
      const payload: any = {
        name: form.name,
        email: form.email,
        role: form.role,
        isActive: !!form.isActive,
      };
      if (form.password) payload.password = form.password;

      if (editing) {
        await api(`/v1/users/${editing.id}`, { method: 'PUT', body: payload, auth: true });
        toast.success('Usuário atualizado.');
      } else {
        if (!payload.password) return toast.error('Defina uma senha.');
        await api('/v1/users', { method: 'POST', body: payload, auth: true });
        toast.success('Usuário criado.');
      }
      onSaved(); onClose();
    } catch (e: any) {
      const msg = e?.error || e?.message || 'Falha ao salvar.';
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
      <div className="card w-full max-w-lg p-0 overflow-hidden">
        <div className="px-5 py-3 border-b border-border bg-card flex items-center justify-between">
          <h3 className="title text-xl m-0">{editing ? 'Editar' : 'Novo'} Usuário</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose} disabled={saving}>Fechar</button>
        </div>

        <div className="px-5 py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="md:col-span-2">
              <span>Nome*</span>
              <input className="input" value={form.name || ''} onChange={e => set('name', e.target.value)} />
            </label>
            <label className="md:col-span-2">
              <span>E-mail*</span>
              <input className="input" type="email" value={form.email || ''} onChange={e => set('email', e.target.value)} />
            </label>
            <label>
              <span>Role*</span>
              <select className="input" value={form.role || 'CONCIERGE'} onChange={e => set('role', e.target.value)}>
                <option value="ADMIN">ADMIN</option>
                <option value="CONCIERGE">CONCIERGE</option>
              </select>
            </label>
            <label>
              <span>Ativo</span>
              <select className="input" value={String(!!form.isActive)} onChange={e => set('isActive', e.target.value === 'true')}>
                <option value="true">Sim</option>
                <option value="false">Não</option>
              </select>
            </label>
            <label className="md:col-span-2">
              <span>{editing ? 'Nova senha' : 'Senha*'}</span>
              <input className="input" type="password" value={form.password || ''} onChange={e => set('password', e.target.value)} />
            </label>
          </div>
        </div>

        <div className="px-5 py-3 border-t border-border bg-card flex justify-end gap-2">
          <button className="btn" onClick={onClose} disabled={saving}>Cancelar</button>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Salvando…' : 'Salvar'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function UsersPage() {
  const [filters, setFilters] = React.useState({ page: 1, pageSize: 20, search: '', active: 'all' });
  const { data, loading } = useUsers(filters);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<any | null>(null);

  return (
    <section className="container mt-4">
      <div className="card">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-2">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 flex-1">
            <label>
              <span>Buscar</span>
              <input className="input" value={filters.search} onChange={e => setFilters({ ...filters, search: e.target.value, page: 1 })} placeholder="nome ou e-mail" />
            </label>
            <label>
              <span>Ativo</span>
              <select className="input" value={filters.active} onChange={e => setFilters({ ...filters, active: e.target.value, page: 1 })}>
                <option value="all">Todos</option>
                <option value="true">Somente ativos</option>
                <option value="false">Somente inativos</option>
              </select>
            </label>
          </div>
          <div className="flex gap-2">
            <button className="btn" onClick={() => setFilters({ ...filters })}>Atualizar</button>
            <button className="btn btn-primary" onClick={() => { setEditing(null); setModalOpen(true); }}>
              Novo Usuário
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th><th>E-mail</th><th>Role</th><th>Ativo</th><th></th>
              </tr>
            </thead>
            {loading ? (
              <tbody>
                {Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i}>
                    <td><Skeleton className="h-4 w-40" /></td>
                    <td><Skeleton className="h-4 w-56" /></td>
                    <td><Skeleton className="h-4 w-20" /></td>
                    <td><Skeleton className="h-4 w-16" /></td>
                    <td className="text-right"><Skeleton className="h-8 w-24" /></td>
                  </tr>
                ))}
              </tbody>
            ) : (
              <tbody>
                {data.items.map(u => (
                  <tr key={u.id}>
                    <td>{u.name}</td>
                    <td>{u.email}</td>
                    <td>{u.role}</td>
                    <td>{u.isActive ? 'Sim' : 'Não'}</td>
                    <td className="text-right">
                      <div className="flex gap-2 justify-end">
                        <button className="btn btn-sm" onClick={() => { setEditing(u); setModalOpen(true); }}>Editar</button>
                        <button
                          className="btn btn-sm btn-danger"
                          onClick={async () => {
                            if (!confirm(`Excluir usuário "${u.name}"?`)) return;
                            try {
                              await api(`/v1/users/${u.id}`, { method: 'DELETE', auth: true });
                              toast.success('Usuário excluído.');
                              setFilters({ ...filters });
                            } catch (e: any) {
                              toast.error(e?.error || e?.message || 'Falha ao excluir.');
                            }
                          }}
                        >Excluir</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {data.items.length === 0 && <tr><td colSpan={5}>Sem resultados</td></tr>}
              </tbody>
            )}
          </table>
        </div>

        <div className="flex items-center justify-center gap-3 text-muted mt-3">
          <button className="btn btn-sm" onClick={() => setFilters(f => ({ ...f, page: Math.max(1, f.page - 1) }))}>◀</button>
          <span>Página {data.page} de {data.totalPages} — {data.total} itens</span>
          <button className="btn btn-sm" onClick={() => setFilters(f => ({ ...f, page: f.page + 1 }))}>▶</button>
        </div>
      </div>

      <UserModal
        open={modalOpen}
        editing={editing}
        onClose={() => setModalOpen(false)}
        onSaved={() => setFilters({ ...filters })}
      />
    </section>
  );
}
